package com.example.registro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Bebidas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button btn9, btn10,fant, btns2;

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_bebidas);
            btn9 = (Button) findViewById(R.id.Coca);
            btn10 = (Button) findViewById(R.id.pep);
            fant= (Button) findViewById(R.id.fanta);
            btns2 = (Button) findViewById(R.id.regreso2);

            btn9.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "coca", Toast.LENGTH_SHORT).show();
                    Intent i= new Intent(getApplicationContext(), Bebidas.class);
                    startActivity(i);
                }

            });
            btn10.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "pepsi", Toast.LENGTH_SHORT).show();
                    Intent i= new Intent(getApplicationContext(), Bebidas.class);
                    startActivity(i);
                }

            });


            btns2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "regresaste al menu", Toast.LENGTH_SHORT).show();
                    Intent i= new Intent(getApplicationContext(),Menu.class);
                    startActivity(i);
                }
            });
        }

    }





