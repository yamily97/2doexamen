package com.example.registro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Pizzas extends AppCompatActivity {

    Button btn7, btn8,cham,btns1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizzas);
        btn7 = (Button) findViewById(R.id.hawai);
        btn8 = (Button) findViewById(R.id.pepero);
        cham= (Button) findViewById(R.id.cham);
        btns1 = (Button) findViewById(R.id.regreso);

        btn7.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "PIZZA DE hawaiana", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(),hawaiana.class);
            startActivity(i);
        }

    });
        btn8.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "PIZZA peperoni", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(), Pizzas.class);
            startActivity(i);
        }
    });
        cham.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "PIZZA Champiniones", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(),Pizzas.class);
            startActivity(i);
        }
        });
    }}



