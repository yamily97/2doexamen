package com.example.registro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Menu extends AppCompatActivity {
    Button btn4, btn5, btn6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        btn4 = (Button) findViewById(R.id.PIZZAS);
        btn5 = (Button) findViewById(R.id.BEBIDAS);
        btn6 = (Button) findViewById(R.id.SALIR);

        btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "SELECCIONASTE PIZZAS", Toast.LENGTH_SHORT).show();
                Intent i= new Intent(getApplicationContext(),Pizzas.class);
                startActivity(i);
            }

        });
        btn5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "SELECCIONASTE BEBIDAS", Toast.LENGTH_SHORT).show();
                Intent i= new Intent(getApplicationContext(),Bebidas.class);
                startActivity(i);
            }

        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
            }

        });


    }


}