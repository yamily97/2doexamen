package com.example.registro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class bebcoca extends AppCompatActivity {

    Button btn15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebcoca);
        btn15 = (Button)findViewById(R.id.comprar2);

        btn15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "gracias por tu compra", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),Bebidas.class);
                startActivity(i);
            }
        });
    }
}