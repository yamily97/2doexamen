package com.example.registro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class hawaiana extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Button btn14;

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_hawaiana);
            btn14 = (Button) findViewById(R.id.comp);

            btn14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "gracias por tu compra", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), Pizzas.class);
                    startActivity(i);
                }
            });
    }
}